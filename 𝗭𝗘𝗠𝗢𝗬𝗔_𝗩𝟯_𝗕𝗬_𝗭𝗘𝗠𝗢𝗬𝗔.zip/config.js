/*
  [ SETTINGS BOT ]
*/
global.owner = ['2349124727062']
global.ownername = "𝗭𝗘𝗠𝗢𝗬𝗔"
global.connect = true // False = QrCode
global.antilink = true
global.autotyping = true
global.welcome = true
global.autoreadsw = false
global.autorecord = true
global.autoswview = true//auto view status/story


//king badboi crack and fix baileys 
/*
  [ PAYMENT BEBAS ]
*/
global.dana = "2349124727062"
global.gopay = "2349124727062"
global.ovo = "2349124727062"
global.qris = "https://files.catbox.moe/x2bhz5.jpeg"

/*
  [ GAUSAH DI UBAH ]
*/
global.mess = {
"ketua": "*ℤ𝔼𝕄𝕆𝕐𝔸 𝗩𝟯.𝟬* Access was denied!",
"prem": "*ℤ𝔼𝕄𝕆𝕐𝔸 𝗩𝟯.𝟬* Access was denied!",
"premium": "*ℤ𝔼𝕄𝕆𝕐𝔸 𝗩𝟯.𝟬* Access was denied!",
"japost": "*ℤ𝔼𝕄𝕆𝕐𝔸 𝗩𝟯.𝟬* Access was denied!",
"rekber": "*ℤ𝔼𝕄𝕆𝕐𝔸 𝗩𝟯.𝟬* Access was denied!",
"owner": "*ℤ𝔼𝕄𝕆𝕐𝔸 𝗩𝟯.𝟬* Access was denied!"
}

/*
  [ GAUSAH DI UBAH ]
*/
global.tele = "t.me/Zbugs"
global.tele2 = "t.me/Zbugs"
global.waMe = "wa.me/2349124727062"
global.tutorialBot = "https://youtube.com/@Cryptolord2"
global.versionofscript = "15.0"
global.url = "https://files.catbox.moe/x2bhz5.jpeg"
global.urlbanner = "https://files.catbox.moe/x2bhz5.jpeg"
global.url2 = "https://t.me/Zbugs"
global.packname = "Stiker By"
global.author = "𝗭𝗘𝗠𝗢𝗬𝗔"
global.group = "https://whatsapp.com/channel/0029VayUeHmE50UYxlX4Km2K"
global.idCH = "120363355743347208@newsletter"
global.xchannel = {
	jid: '120363355743347208@newsletter'
	}
	